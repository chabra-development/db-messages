"use client"

import { ReactQueryDevtools } from "@tanstack/react-query-devtools"

export const QueryDevtools = () => <ReactQueryDevtools initialIsOpen={false} />
