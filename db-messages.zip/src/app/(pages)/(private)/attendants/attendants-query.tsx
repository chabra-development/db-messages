"use client"

import { findManyAttendants } from "@/actions/attendants/find-many-attendants"
import {
    ImportAttendantsForm
} from "@/components/forms/form-import-attendants/import-attendants-form"
import { Pagination } from "@/components/pagination"
import { SearchInput } from "@/components/seach-input"
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger
} from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import {
    Card,
    CardAction,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle
} from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { authClient } from "@/lib/auth-client"
import { cn } from "@/lib/utils"
import { Role, User } from "@prisma/client"
import { useQuery } from "@tanstack/react-query"
import { motion } from "framer-motion"
import { Filter } from "lucide-react"
import { useSearchParams } from "next/navigation"
import { useState } from "react"
import { AttendantsQueryLoading } from "./attendants-query-loading"
import { ChangeRoleUserDialog } from "./change-role-attendants"
import { AttendantCard } from "./attendant-card"

export const AttendantsQuery = () => {

    const searchParams = useSearchParams()

    const [search, setSearch] = useState("")
    const [selectedTeams, setSelectedTeams] = useState<Set<string>>(new Set())

    const take = searchParams.get("take")
    const skip = searchParams.get("skip")

    const { data } = authClient.useSession()

    const {
        data: dataAttendants,
        isLoading
    } = useQuery({
        queryKey: ["find-many-attendants", take, skip],
        queryFn: () => findManyAttendants({
            skip,
            take,
            orderBy: {
                name: "asc"
            }
        })
    })

    if (isLoading || !dataAttendants || !data) {
        return (
            <AttendantsQueryLoading />
        )
    }

    const { data: attendants, page, totalPages, count } = dataAttendants

    const uniqueTeams = [
        ...new Set(attendants.flatMap((a) => a.teams ?? [])),
    ].sort()

    const term = search.trim().toLowerCase()
    const hasTeamFilter = selectedTeams.size > 0

    const filteredAttendants = attendants.filter(({ name, email, teams = [] }) => {
        const matchesSearch =
            !term ||
            name.toLowerCase().includes(term) ||
            email.toLowerCase().includes(term) ||
            teams.some((t) => t.toLowerCase().includes(term))

        const matchesTeams = !hasTeamFilter || teams.some((t) => selectedTeams.has(t))

        return matchesSearch && matchesTeams
    })

    const toggleTeam = (team: string) => {
        setSelectedTeams((prev) => {

            const next = new Set(prev)

            if (next.has(team)) next.delete(team)
            else next.add(team)

            return next
        })
    }

    const { role } = data.user as User

    return (
        <Card className="flex-1 border-none rounded-none gap-0">
            <CardHeader className="border-b py-4">
                <div className="flex flex-col gap-3 min-w-0">
                    <SearchInput
                        placeholder="Pesquisar atendente..."
                        classNameDiv="w-2/3"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    {uniqueTeams.length > 0 && (
                        <Accordion type="single" collapsible className="w-full">
                            <AccordionItem value="teams-filter">
                                <AccordionTrigger
                                    className="w-2/3 px-4 flex-none"
                                >
                                    <div className="flex gap-2 items-center">
                                        <Filter className="size-4" />
                                        Filtrar por lista
                                    </div>
                                    {/* <ChevronDown /> */}
                                    {selectedTeams.size > 0 && (
                                        <span className="ml-2 text-muted-foreground">
                                            ({selectedTeams.size} selecionada
                                            {selectedTeams.size === 1 ? "" : "s"})
                                        </span>
                                    )}
                                </AccordionTrigger>
                                <AccordionContent className="pt-2">
                                    <div className="flex flex-wrap items-center gap-2">
                                        {uniqueTeams.map((team) => (
                                            <Badge
                                                key={team}
                                                variant={selectedTeams.has(team) ? "default" : "secondary"}
                                                className="cursor-pointer px-3 py-1.5 rounded-md transition-colors hover:opacity-90"
                                                onClick={() => toggleTeam(team)}
                                                role="button"
                                                tabIndex={0}
                                                onKeyDown={(e) => {
                                                    if (e.key === "Enter" || e.key === " ") {
                                                        e.preventDefault()
                                                        toggleTeam(team)
                                                    }
                                                }}
                                            >
                                                {team}
                                            </Badge>
                                        ))}
                                    </div>
                                </AccordionContent>
                            </AccordionItem>
                        </Accordion>
                    )}
                </div>
                {
                    role === "ADMIN" && (
                        <CardAction>
                            <ImportAttendantsForm />
                        </CardAction>
                    )
                }
            </CardHeader>
            <ScrollArea className="min-h-0 flex-1 py-6">
                <CardContent className="grid grid-cols-2 gap-2 space-y-2 px-2">
                    {filteredAttendants.length === 0 ? (
                        <p className="col-span-2 text-center text-muted-foreground py-8">
                            {term || hasTeamFilter
                                ? "Nenhum atendente encontrado para os filtros aplicados."
                                : "Nenhum atendente cadastrado."}
                        </p>
                    ) : (
                        filteredAttendants.map((attendant, index) => (
                            <AttendantCard
                                key={attendant.id}
                                attendant={attendant}
                                index={index}
                            />
                        ))
                    )}
                </CardContent>
            </ScrollArea>
            <CardFooter className="border-t">
                <Pagination
                    paginationData={{ page, take, totalPages, count }}
                />
            </CardFooter>
        </Card>
    )
}  